<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    // Perform any necessary validation and sanitization on the data.

    $to = 'anikesh922@gmail.com'; // Replace with your recipient's email address
    $subject = 'Contact Form Submission';
    $messageBody = "Name: $name\nEmail: $email\nPhone: $phone\nMessage:\n$message";

    $headers = 'From: editor@pijst.com';

    if (mail($to, $subject, $messageBody, $headers)) {
        // Email sent successfully
        echo 'Email sent successfully';
    } else {
        // Email sending failed
        echo 'Email sending failed';
    }
} else {
    echo 'Invalid request';
}
?>
