<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $paperTitle = $_POST["paper-title"];
    $author = $_POST["author"];
    $researchArea = $_POST["research-area"];
    $abstract = $_POST["abstract"];
    $file = $_FILES["file"]["name"];

    // Authors/Co-Authors Details
    $name = $_POST["name"];
    $designation = $_POST["designation"];
    $organization = $_POST["organization"];
    $email = $_POST["email"];
    $mobile = $_POST["mobile"];

    // Co-Authors 1
    $coAuthorAName = $_POST["co-author-a-name"];
    $coAuthorADesignation = $_POST["co-author-a-designation"];
    $coAuthorAOrganization = $_POST["co-author-a-organization"];
    $coAuthorAEmail = $_POST["co-author-a-email"];
    $coAuthorAMobile = $_POST["co-author-a-mobile"];

    // Co-Authors 2
    $coAuthorBName = $_POST["co-author-b-name"];
    $coAuthorBDesignation = $_POST["co-author-b-designation"];
    $coAuthorBOrganization = $_POST["co-author-b-organization"];
    $coAuthorBEmail = $_POST["co-author-b-email"];
    $coAuthorBMobile = $_POST["co-author-b-mobile"];

    // Co-Authors 3
    $coAuthorCName = $_POST["co-author-c-name"];
    $coAuthorCDesignation = $_POST["co-author-c-designation"];
    $coAuthorCOrganization = $_POST["co-author-c-organization"];
    $coAuthorCEmail = $_POST["co-author-c-email"];
    $coAuthorCMobile = $_POST["co-author-c-mobile"];

    // Address of Communication
    $address = $_POST["address"];
    $addressA = $_POST["address-a"];
    $city = $_POST["city"];
    $state = $_POST["state"];
    $country = $_POST["country"];
    $pincode = $_POST["pincode"];

    // Captcha
    $captcha = $_POST["captcha"];

    // Validate captcha
    if ($captcha != 5) {
        die("Captcha verification failed.");
    }

    // Email content
    $to = "anikesh922@gmail.com";
    $toEditor = "editor@pijst.com";
    $subject = "New Paper Submission: " . $paperTitle;
    $message = "
    Paper Title: $paperTitle\n
    Author(s) Name: $author\n
    Research Area/Subject: $researchArea\n
    Abstract: $abstract\n
    File: $file\n
    Authors/Co-Authors Details:\n
    Name: $name\n
    Designation: $designation\n
    Institute/Organization: $organization\n
    Email Id: $email\n
    Mobile No.: $mobile\n
    Co-Authors 1:\n
    Name: $coAuthorAName\n
    Designation: $coAuthorADesignation\n
    Institute/Organization: $coAuthorAOrganization\n
    Email Id: $coAuthorAEmail\n
    Mobile No.: $coAuthorAMobile\n
    Co-Authors 2:\n
    Name: $coAuthorBName\n
    Designation: $coAuthorBDesignation\n
    Institute/Organization: $coAuthorBOrganization\n
    Email Id: $coAuthorBEmail\n
    Mobile No.: $coAuthorBMobile\n
    Co-Authors 3:\n
    Name: $coAuthorCName\n
    Designation: $coAuthorCDesignation\n
    Institute/Organization: $coAuthorCOrganization\n
    Email Id: $coAuthorCEmail\n
    Mobile No.: $coAuthorCMobile\n
    Address of Communication:\n
    Address Line 1: $address\n
    Address Line 2: $addressA\n
    City/District: $city\n
    State: $state\n
    Country: $country\n
    Postal Code: $pincode\n
    ";

    // Headers
    $headers = "From: editor@pijst.com"; // Change this to a valid email address

    $mail = mail($to, $subject, $message, $headers);
    $mailEditor = mail($toEditor, $subject, $message, $headers);

    // Send email
    if (mail($mail && $mailEditor)) {
        echo "Thank you for submitting your paper. We will contact you shortly.";
    } else {
        echo "Error sending email. Please try again later.";
    }
} else {
    // If the form is not submitted, redirect to the form page
    echo 'Invalid request';
    // exit();
}
?>
